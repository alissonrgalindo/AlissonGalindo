// src/lib/services/enhancedDocumentService.ts
import { OpenAIEmbeddings } from '@langchain/openai';
import { SupabaseVectorStore } from '@langchain/community/vectorstores/supabase';
import { RecursiveCharacterTextSplitter } from 'langchain/text_splitter';
import { Document } from 'langchain/document';
import { createAdminClient } from './supabaseClient';
import { OpenAI } from 'openai';
import { LangChainTracer } from "langchain/callbacks";
import { 
  StructuredOutputParser, 
  OutputFixingParser
} from "langchain/output_parsers";
import { z } from "zod";
import { PromptTemplate } from "langchain/prompts";
import { ChatOpenAI } from "@langchain/openai";

// Define the expected document types
export type DocumentType = 'cv' | 'portfolio' | 'project' | 'blog' | 'github' | 'linkedin' | 'other';

// Define the metadata interface
export interface DocumentMetadata {
  document_id: string;
  title: string;
  type: DocumentType;
  source: string;
  chunk_index: number;
  extracted_entities?: ExtractedEntities;
}

// Define the structure for extracted entities
export interface ExtractedEntities {
  technologies: string[];
  skills: string[];
  experiences: Experience[];
  projects: Project[];
  education: Education[];
}

// Define experience interface
export interface Experience {
  company: string;
  title: string;
  startDate: string;
  endDate?: string;
  description?: string;
  technologies?: string[];
  yearsOfExperience?: number;
}

// Define project interface
export interface Project {
  name: string;
  description?: string;
  technologies?: string[];
  url?: string;
  repository?: string;
}

// Define education interface
export interface Education {
  institution: string;
  degree: string;
  field?: string;
  startDate: string;
  endDate?: string;
}

// Define the result interface
export interface ProcessDocumentResult {
  success: boolean;
  documentId?: string;
  chunkCount?: number;
  error?: string;
  extractedEntities?: ExtractedEntities;
}

// Constants
const CHUNK_SIZE = 1000;
const CHUNK_OVERLAP = 200;
const EMBEDDING_MODEL = 'text-embedding-3-small';
const SMITH_PROJECT_NAME = "document-extraction";

// Initialize the embeddings with OpenAI
const embeddings = new OpenAIEmbeddings({
  openAIApiKey: process.env.OPENAI_API_KEY,
  modelName: EMBEDDING_MODEL,
});

// Initialize the OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Initialize LangChain Chat Model
const chatModel = new ChatOpenAI({
  openAIApiKey: process.env.OPENAI_API_KEY,
  modelName: "gpt-4o",
  temperature: 0.2,
});

// Get the vector store
export const getVectorStore = () => {
  const client = createAdminClient();
  
  return new SupabaseVectorStore(embeddings, {
    client,
    tableName: 'documents',
    queryName: 'match_documents',
  });
};

// Function to create a LangChain tracer
const createTracer = async (runName: string) => {
  const smithApiKey = process.env.LANGCHAIN_API_KEY;
  if (!smithApiKey) {
    console.warn('LANGCHAIN_API_KEY not found. Smith tracing disabled.');
    return null;
  }

  try {
    return new LangChainTracer({
      projectName: SMITH_PROJECT_NAME,
      client: "langchain",
      sessionName: runName,
    });
  } catch (error) {
    console.error('Error creating Smith tracer:', error);
    return null;
  }
};

// Function to split documents into chunks
export const splitDocumentIntoChunks = async (
  text: string,
  metadata: Omit<DocumentMetadata, 'chunk_index'>
): Promise<Document[]> => {
  const splitter = new RecursiveCharacterTextSplitter({
    chunkSize: CHUNK_SIZE,
    chunkOverlap: CHUNK_OVERLAP,
  });
  
  const docs = await splitter.createDocuments(
    [text],
    [metadata]
  );
  
  return docs.map((doc, i) => {
    return new Document({
      pageContent: doc.pageContent,
      metadata: {
        ...doc.metadata,
        chunk_index: i,
      },
    });
  });
};

// Create a structured parser for entity extraction
const createEntityExtractionParser = () => {
  const parser = StructuredOutputParser.fromZodSchema(
    z.object({
      technologies: z.array(z.string()).describe("List of technology names mentioned in the document"),
      skills: z.array(z.string()).describe("List of skills mentioned in the document"),
      experiences: z.array(z.object({
        company: z.string().describe("Name of the company"),
        title: z.string().describe("Job title"),
        startDate: z.string().describe("Start date of employment (YYYY-MM format)"),
        endDate: z.string().optional().describe("End date of employment (YYYY-MM format) if applicable"),
        description: z.string().optional().describe("Job description"),
        technologies: z.array(z.string()).optional().describe("Technologies used in this position"),
        yearsOfExperience: z.number().optional().describe("Years of experience in this position")
      })).describe("List of work experiences"),
      projects: z.array(z.object({
        name: z.string().describe("Name of the project"),
        description: z.string().optional().describe("Project description"),
        technologies: z.array(z.string()).optional().describe("Technologies used in the project"),
        url: z.string().optional().describe("URL of the deployed project"),
        repository: z.string().optional().describe("URL of the project repository")
      })).describe("List of projects"),
      education: z.array(z.object({
        institution: z.string().describe("Name of the educational institution"),
        degree: z.string().describe("Degree obtained"),
        field: z.string().optional().describe("Field of study"),
        startDate: z.string().describe("Start date (YYYY-MM format)"),
        endDate: z.string().optional().describe("End date (YYYY-MM format) if applicable")
      })).describe("List of educational backgrounds")
    })
  );

  // Create a fixing parser to handle potential errors in the output
  return OutputFixingParser.fromLLM(chatModel, parser);
};

// Function to extract entities from document text
export const extractEntitiesFromDocument = async (
  text: string,
  documentType: DocumentType
): Promise<ExtractedEntities> => {
  const tracer = await createTracer("entity-extraction");
  const parser = createEntityExtractionParser();
  
  // Create a prompt template for entity extraction
  const promptTemplate = PromptTemplate.fromTemplate(`
    You are an expert data extractor. Your task is to extract structured information from the document provided.
    The document is of type: {documentType}
    
    Extract the following information in a structured format:
    1. Technologies mentioned
    2. Skills mentioned
    3. Work experiences with details (company, title, dates, description, technologies used)
    4. Projects with details (name, description, technologies, URLs)
    5. Education details (institution, degree, field, dates)
    
    Document content:
    {text}
    
    {format_instructions}
  `);
  
  // Format the prompt with the document text and parsing instructions
  const prompt = await promptTemplate.format({
    documentType,
    text: text.slice(0, 8000), // Limit text length to avoid token limits
    format_instructions: parser.getFormatInstructions(),
  });
  
  // Generate the structured output
  const callbacks = tracer ? [tracer] : undefined;
  const model = chatModel.bind({ callbacks });
  const result = await model.invoke(prompt);
  
  // Parse the result into structured format
  try {
    return await parser.parse(result.content);
  } catch (error) {
    console.error("Error parsing entity extraction result:", error);
    // Return default empty structure if parsing fails
    return {
      technologies: [],
      skills: [],
      experiences: [],
      projects: [],
      education: []
    };
  }
};

// Main function to process documents
export const processDocumentEnhanced = async (
  text: string,
  metadata: Omit<DocumentMetadata, 'chunk_index'>
): Promise<ProcessDocumentResult> => {
  try {
    const tracer = await createTracer(`process-document-${metadata.document_id}`);
    const callbacks = tracer ? [tracer] : undefined;
    
    // Extract entities from the document
    const extractedEntities = await extractEntitiesFromDocument(text, metadata.type);
    
    // Split the document into chunks
    const chunks = await splitDocumentIntoChunks(text, {
      ...metadata,
      extracted_entities: extractedEntities
    });
    
    // Initialize vector store and add documents
    const vectorStore = getVectorStore();
    await vectorStore.addDocuments(chunks);
    
    // Update document metadata in Supabase
    const supabase = createAdminClient();
    await supabase
      .from('documents_metadata')
      .upsert({
        id: metadata.document_id,
        title: metadata.title,
        type: metadata.type,
        source: metadata.source,
        chunk_count: chunks.length,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        extracted_metadata: JSON.stringify(extractedEntities)
      });
    
    return {
      success: true,
      documentId: metadata.document_id,
      chunkCount: chunks.length,
      extractedEntities
    };
  } catch (error) {
    console.error('Error processing document:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error occurred',
    };
  }
};

// Function to perform enhanced similarity search
export const performEnhancedSearch = async (
  query: string,
  options: {
    limit?: number;
    filterMetadata?: Record<string, any>;
  } = {}
) => {
  const tracer = await createTracer(`search-query-${Date.now()}`);
  const callbacks = tracer ? [tracer] : undefined;
  
  const { limit = 5, filterMetadata = {} } = options;
  const vectorStore = getVectorStore();
  
  // Extract entities from the query to enhance search
  const queryEntities = await extractQueryEntities(query);
  
  // Create a metadata filter based on extracted entities
  const metadataFilter = createMetadataFilter(queryEntities, filterMetadata);
  
  // Perform the similarity search
  const results = await vectorStore.similaritySearch(
    query,
    limit,
    metadataFilter
  );
  
  return results;
};

// Function to extract entities from a query
const extractQueryEntities = async (query: string) => {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `Extract key entities from the user query, focusing on:
            - technologies or programming languages
            - skills
            - experience levels (e.g., "3 years of experience")
            - project types
            - industries
            
            Return a JSON object with these keys: technologies, skills, experienceLevels, projectTypes, industries.
            Each key should have an array value, which can be empty if not found.`
        },
        {
          role: "user",
          content: query
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.2,
    });
    
    const content = response.choices[0]?.message.content;
    if (!content) return {};
    
    return JSON.parse(content);
  } catch (error) {
    console.error("Error extracting query entities:", error);
    return {};
  }
};

// Function to create metadata filter
const createMetadataFilter = (
  queryEntities: any,
  additionalFilters: Record<string, any> = {}
) => {
  const filter: Record<string, any> = { ...additionalFilters };
  
  // Add technology filters
  if (queryEntities.technologies?.length > 0) {
    filter['metadata.extracted_entities.technologies'] = {
      $containsAny: queryEntities.technologies
    };
  }
  
  // Add skill filters
  if (queryEntities.skills?.length > 0) {
    filter['metadata.extracted_entities.skills'] = {
      $containsAny: queryEntities.skills
    };
  }
  
  // Add project type filters
  if (queryEntities.projectTypes?.length > 0) {
    filter['metadata.extracted_entities.projects.name'] = {
      $containsAny: queryEntities.projectTypes
    };
  }
  
  return filter;
};

// Function to generate a response with context
export const generateEnhancedResponse = async (
  query: string,
  context: Document[],
  options: {
    conversationHistory?: { role: string; content: string }[];
    temperature?: number;
  } = {}
) => {
  const tracer = await createTracer(`generate-response-${Date.now()}`);
  const { conversationHistory = [], temperature = 0.6 } = options;
  
  // Format the context for the prompt
  const formattedContext = context.map((doc, index) => {
    const entityInfo = doc.metadata.extracted_entities 
      ? formatEntityInfo(doc.metadata.extracted_entities)
      : '';
      
    return `DOCUMENT ${index + 1}:
Source: ${doc.metadata.source || 'Unknown'}
Title: ${doc.metadata.title || 'Untitled'}
Type: ${doc.metadata.type || 'Unknown'}
${entityInfo}
Content: ${doc.pageContent}
`;
  }).join('\n\n');
  
  // Build the system prompt
  const systemPrompt = `
You are an AI assistant representing Alison Galindo, a senior frontend developer based in Caruaru, Pernambuco, Brazil.

IMPORTANT GUIDELINES:
1. Keep your responses concise but informative (3-5 sentences is ideal).
2. Only discuss technologies and experiences that are actually in Alison's CV and portfolio documents.
3. Do NOT claim expertise or work experience with technologies not mentioned in the provided context.
4. If asked about a technology or skill not in the context, simply say you don't have significant experience with it.
5. Focus on your main expertise: React, Next.js, and modern frontend development.

CONTEXT FROM DOCUMENTS:
${formattedContext}

Remember, always only reference technologies and experiences from the provided context or previously verified experience. When appropriate, provide specific information about years of experience, projects, and insights about technologies.
`;

  // Build the messages array
  const messages = [
    { role: "system", content: systemPrompt },
    ...conversationHistory,
    { role: "user", content: query }
  ];
  
  // Generate the response
  const callbacks = tracer ? [tracer] : undefined;
  const response = await chatModel.bind({ 
    callbacks,
    temperature
  }).invoke(messages.map(m => ({
    role: m.role,
    content: m.content
  })));
  
  return response.content;
};

// Helper function to format entity information for the prompt
const formatEntityInfo = (entities: ExtractedEntities) => {
  let info = '';
  
  if (entities.technologies?.length > 0) {
    info += `Technologies: ${entities.technologies.join(', ')}\n`;
  }
  
  if (entities.skills?.length > 0) {
    info += `Skills: ${entities.skills.join(', ')}\n`;
  }
  
  if (entities.experiences?.length > 0) {
    info += 'Experiences:\n';
    entities.experiences.forEach(exp => {
      const duration = exp.endDate 
        ? `${exp.startDate} to ${exp.endDate}`
        : `${exp.startDate} to Present`;
      info += `- ${exp.title} at ${exp.company} (${duration})`;
      if (exp.technologies) {
        info += `, Technologies: ${exp.technologies.join(', ')}`;
      }
      info += '\n';
    });
  }
  
  if (entities.projects?.length > 0) {
    info += 'Projects:\n';
    entities.projects.forEach(project => {
      info += `- ${project.name}`;
      if (project.technologies) {
        info += `, Technologies: ${project.technologies.join(', ')}`;
      }
      info += '\n';
    });
  }
  
  return info;
};

// Main function to interact with the RAG system
export async function enhancedChatWithDocuments(
  query: string,
  options: {
    conversationHistory?: { role: string; content: string }[];
    temperature?: number;
    retrievalCount?: number;
  } = {}
): Promise<{
  message: string;
  context?: Document[];
  error?: string;
}> {
  try {
    const { 
      conversationHistory = [],
      temperature = 0.6,
      retrievalCount = 5
    } = options;
    
    // Perform the enhanced search
    const contextDocuments = await performEnhancedSearch(query, {
      limit: retrievalCount
    });
    
    // If no results found, return a fallback message
    if (contextDocuments.length === 0) {
      return {
        message: "I don't have specific information about that in my CV or portfolio. Can I assist you with something related to my frontend development experience instead?",
        context: []
      };
    }
    
    // Generate a response using the retrieved context
    const response = await generateEnhancedResponse(query, contextDocuments, {
      conversationHistory,
      temperature
    });
    
    return {
      message: response,
      context: contextDocuments
    };
    
  } catch (error) {
    console.error('Error in enhancedChatWithDocuments:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    
    return {
      message: "I'm sorry, I encountered an error processing your request. Please try again.",
      error: errorMessage
    };
  }
}
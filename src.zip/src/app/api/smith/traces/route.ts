// src/app/api/smith/traces/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/services/supabaseClient';

interface TraceQueryParams {
  project?: string;
  session?: string;
  limit?: number;
  offset?: number;
}

export async function GET(req: NextRequest) {
  try {
    // Parse query parameters
    const url = new URL(req.url);
    const project = url.searchParams.get('project') || undefined;
    const session = url.searchParams.get('session') || undefined;
    const limit = parseInt(url.searchParams.get('limit') || '20', 10);
    const offset = parseInt(url.searchParams.get('offset') || '0', 10);
    
    // Get traces from database
    const traces = await getTraces({ project, session, limit, offset });
    
    return NextResponse.json({ traces });
  } catch (error) {
    console.error('Error fetching traces:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    
    return NextResponse.json(
      { error: errorMessage },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    // Parse request body
    const body = await req.json();
    
    // Validate trace data
    if (!body.run_id || !body.project_name) {
      return NextResponse.json(
        { error: 'Missing required fields: run_id, project_name' },
        { status: 400 }
      );
    }
    
    // Store trace in database
    await storeTrace(body);
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error storing trace:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    
    return NextResponse.json(
      { error: errorMessage },
      { status: 500 }
    );
  }
}

// Get traces from the database
async function getTraces(params: TraceQueryParams) {
  const { project, session, limit, offset } = params;
  const supabase = createAdminClient();
  
  let query = supabase
    .from('smith_traces')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(limit)
    .range(offset, offset + limit - 1);
  
  if (project) {
    query = query.eq('project_name', project);
  }
  
  if (session) {
    query = query.eq('session_name', session);
  }
  
  const { data, error } = await query;
  
  if (error) throw error;
  
  return data || [];
}

// Store a trace in the database
async function storeTrace(traceData: any) {
  const supabase = createAdminClient();
  
  const { error } = await supabase
    .from('smith_traces')
    .insert({
      run_id: traceData.run_id,
      parent_run_id: traceData.parent_run_id,
      project_name: traceData.project_name,
      session_name: traceData.session_name,
      start_time: traceData.start_time,
      end_time: traceData.end_time,
      status: traceData.status,
      inputs: traceData.inputs,
      outputs: traceData.outputs,
      error: traceData.error,
      metadata: traceData.metadata
    });
  
  if (error) throw error;
}
// src/app/api/chat/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { enhancedChatWithDocuments } from '@/lib/services/enhancedDocumentService';
import { createAdminClient } from '@/lib/services/supabaseClient';
import { v4 as uuidv4 } from 'uuid';

export interface Message {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

interface ChatRequest {
  message: string;
  history?: Message[];
  conversationId?: string;
  options?: {
    maxContextLength?: number;
    temperature?: number;
    retrievalEnabled?: boolean;
    retrievalCount?: number;
    includeHistory?: boolean;
  };
}

export async function POST(req: NextRequest) {
  try {
    // Parse the request body
    const body = await req.json() as ChatRequest;
    const { message, history, conversationId, options = {} } = body;
    
    // Validate the message
    if (!message) {
      return NextResponse.json(
        { error: 'Message is required' },
        { status: 400 }
      );
    }
    
    // Set default options
    const chatOptions = {
      maxContextLength: options.maxContextLength || 8,
      temperature: options.temperature || 0.7,
      retrievalEnabled: options.retrievalEnabled !== false, 
      retrievalCount: options.retrievalCount || 5,
      includeHistory: options.includeHistory !== false,
    };
    
    // Get conversation history if available
    let conversationHistory: Message[] = [];
    let newConversationId = conversationId;
    
    if (chatOptions.includeHistory) {
      if (conversationId) {
        // Fetch history from database
        conversationHistory = await getConversationHistory(conversationId);
      } else if (history && history.length > 0) {
        // Use provided history
        conversationHistory = history;
        
        // Create a new conversation in the database
        newConversationId = await createConversation();
        
        // Store the history in the database
        for (const msg of history) {
          await storeMessage(newConversationId, msg.role, msg.content);
        }
      } else {
        // Create a new conversation
        newConversationId = await createConversation();
      }
    }
    
    // Format conversation history for the enhanced document service
    const formattedHistory = conversationHistory.map(msg => ({
      role: msg.role,
      content: msg.content
    }));
    
    // Process the chat request
    const response = await enhancedChatWithDocuments(message, {
      conversationHistory: formattedHistory,
      temperature: chatOptions.temperature,
      retrievalCount: chatOptions.retrievalCount
    });
    
    // Store the new messages in the database if including history
    if (chatOptions.includeHistory && newConversationId) {
      await storeMessage(newConversationId, 'user', message);
      await storeMessage(newConversationId, 'assistant', response.message);
    }
    
    // Return the response
    return NextResponse.json({
      message: response.message,
      conversationId: newConversationId,
      context: response.context ? response.context.map(formatContextForResponse) : undefined
    });
    
  } catch (error) {
    console.error('Error in chat API route:', error);
    const errorDetails = error instanceof Error ? error.message : 'Unknown error';
    
    return NextResponse.json(
      { 
        error: 'Failed to process chat request',
        message: "I'm sorry, I encountered an unexpected error. Please try again.",
        details: errorDetails
      },
      { status: 500 }
    );
  }
}

// Helper functions

async function createConversation(): Promise<string> {
  const supabase = createAdminClient();
  const conversationId = uuidv4();
  
  const { error } = await supabase
    .from('chat_conversations')
    .insert({
      id: conversationId,
      started_at: new Date().toISOString(),
      last_message_at: new Date().toISOString()
    });
    
  if (error) throw error;
  return conversationId;
}

async function storeMessage(
  conversationId: string,
  role: 'user' | 'assistant' | 'system',
  content: string
): Promise<void> {
  const supabase = createAdminClient();
  
  const { error } = await supabase
    .from('chat_messages')
    .insert({
      conversation_id: conversationId,
      role,
      content
    });
    
  if (error) throw error;
  
  await supabase
    .from('chat_conversations')
    .update({ last_message_at: new Date().toISOString() })
    .eq('id', conversationId);
}

async function getConversationHistory(conversationId: string): Promise<Message[]> {
  const supabase = createAdminClient();
  
  const { data, error } = await supabase
    .from('chat_messages')
    .select('role, content, created_at')
    .eq('conversation_id', conversationId)
    .order('created_at', { ascending: true });
    
  if (error) throw error;
  
  if (!data) return [];
  
  return data.map(message => ({
    role: message.role as 'user' | 'assistant' | 'system',
    content: message.content,
  }));
}

function formatContextForResponse(doc: any) {
  // Format the document context for the response
  return {
    content: doc.pageContent,
    metadata: {
      title: doc.metadata.title || 'Untitled',
      source: doc.metadata.source || 'Unknown',
      type: doc.metadata.type || 'Unknown',
      entities: doc.metadata.extracted_entities || {}
    }
  };
}